 <div class="page-footer">
            <div class="page-footer-inner"> Designed and Developed by 
             <a href="https://accentelsoft.com/" target="_new">
            ACCENTEL SOFTWARE SOLUTIONS PVT LTD..</a>
           
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- end footer -->
    </div>
    <!-- start js include path -->
    <script src="../../assets/jquery.min.js" ></script>
    <script src="../../assets/popper/popper.js" ></script>
    <script src="../../assets/jquery.blockui.min.js" ></script>
	<script src="../../assets/jquery.slimscroll.js"></script>
    <!-- bootstrap -->
    <script src="../../assets/bootstrap/js/bootstrap.min.js" ></script>
    <script src="../../assets/bootstrap-switch/js/bootstrap-switch.min.js" ></script>
    
 <script src="../../assets/datatables/jquery.dataTables.min.js" ></script>
 	<script src="../../assets/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js" ></script>
    <script src="../../assets/table_data.js" ></script>
    
    <!-- counterup -->
    <script src="../../assets/counterup/jquery.waypoints.min.js" ></script>
    <script src="../../assets/counterup/jquery.counterup.min.js" ></script>
    <!-- Common js-->
	<script src="../../assets/app.js" ></script>
    <script src="../../assets/layout.js" ></script>
    <script src="../../assets/theme-color.js" ></script>
    <!-- material -->
    <script src="../../assets/material/material.min.js"></script>
    <!-- chart js -->
    <script src="../../assets/chart-js/Chart.bundle.js" ></script>
    <script src="../../assets/chart-js/utils.js" ></script>
    <script src="../../assets/chart-js/home-data3.js" ></script>
    <script src="../../assets/sparkline/jquery.sparkline.js" ></script>
	<script src="../../assets/sparkline/sparkline-data.js" ></script>

    <!-- end js include path -->
  </body>

<!-- Mirrored from radixtouch.in/templates/admin/redstar/source/light/dashboard3.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 21 Jul 2018 11:04:33 GMT -->
</html>